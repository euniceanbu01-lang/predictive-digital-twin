import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.main import run_digital_twin

print("WebJob Triggered")
run_digital_twin()
print("WebJob Finished")
