import sys
import os

# Azure App Service root directory
APP_PATH = "/home/site/wwwroot"

# Add app root to Python path
sys.path.append(APP_PATH)

from backend.main import run_digital_twin

print("WebJob Triggered")
run_digital_twin()
print("WebJob Finished")
